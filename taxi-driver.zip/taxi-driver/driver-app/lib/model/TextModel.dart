import 'package:flutter/material.dart';

class TexIModel {
  String? img;
  String? subTitle;
  String? title;
  IconData? iconData;

  TexIModel({this.img, this.subTitle, this.title,this.iconData});
}
