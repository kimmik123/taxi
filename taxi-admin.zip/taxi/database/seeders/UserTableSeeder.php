<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class UserTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        DB::table('users')->delete();
        
        DB::table('users')->insert(array (
            0 => 
            array (
                'id' => 1,
                'first_name' => 'Blue Taxi',
                'last_name' => 'Admin',
                'username' => 'BlueTaxi',
                'contact_number' => '+639876543210',
                'address' => 'Sta. Isabel Bldg., Balibago, Angeles City, Pampanga',
                'email' => 'bluetaxi@admin.com',
                'password' => bcrypt('BlueTaxiAdmin2023'),
                'email_verified_at' => NULL,
                'user_type' => 'admin',
                'player_id' => NULL,
                'remember_token' => NULL,
                'last_notification_seen' => NULL,
                'status' => 'active',
                'timezone' => 'UTC',
                'display_name' => 'Admin',
                'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
                'updated_at' => NULL,
            )
        ));
        
        
    }
}