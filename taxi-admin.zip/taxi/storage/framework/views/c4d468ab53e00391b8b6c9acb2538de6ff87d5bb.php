<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8">
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.riderequest')); ?></h4>
                        </div>
                        <h4 class="float-right">#<?php echo e($data->id); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <h4><?php echo e(__('message.pickup_address')); ?></h4>
                                <p><?php echo e($data->start_address); ?></p>
                            </div>
                            <div class="col-6">
                                <h4><?php echo e(__('message.drop_address')); ?></h4>
                                <p><?php echo e($data->end_address); ?></p>
                            </div>
                        </div>
                        <?php if(optional($data)->payment != null && optional($data)->payment->payment_status == 'paid'): ?>
                            <hr>
                            <div class="row">
                                <div class="col-3">
                                    <p><?php echo e(__('message.total_distance')); ?></p>
                                    <?php echo e($data->distance); ?> <?php echo e($data->distance_unit); ?>

                                </div>
                                <div class="col-3">
                                    <p><?php echo e(__('message.total_duration')); ?></p>
                                    <?php echo e($data->duration); ?> <?php echo e(__('message.min')); ?>

                                </div>
                                <div class="col-3">
                                    <p><?php echo e(__('message.admin_commission')); ?></p>
                                    <?php echo e(getPriceFormat(optional($data->payment)->admin_commission ?? 0 )); ?>

                                </div>
                                <div class="col-3">
                                    <p><?php echo e(__('message.driver_earning')); ?></p>
                                    <?php echo e(getPriceFormat(optional($data->payment)->driver_commission ?? 0 )); ?>

                                </div> 
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.payment')); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if(optional($data)->payment != null && optional($data)->payment->payment_status == 'paid'): ?>
                            <?php
                            $distance_unit = $data->distance_unit;
                            ?>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.base_fare')); ?></span>
                                    <span><?php echo e(__('message.for_first')); ?> <?php echo e($data->base_distance); ?> <?php echo e(__('message.'.$distance_unit)); ?></span>
                                    <span class=""><?php echo e(getPriceFormat($data->base_fare)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.distance')); ?></span>
                                    <?php if($data->distance > $data->base_distance): ?>
                                        <span><?php echo e($data->distance - $data->base_distance); ?> <?php echo e($distance_unit); ?> x <?php echo e($data->per_distance); ?>/<?php echo e(__('message.'.$distance_unit)); ?></span>
                                    <?php else: ?>
                                        <span><?php echo e($data->distance); ?> <?php echo e($distance_unit); ?> x <?php echo e($data->per_distance); ?>/<?php echo e(__('message.'.$distance_unit)); ?></span>
                                    <?php endif; ?>
                                    <span class=""><?php echo e(getPriceFormat($data->per_distance_charge)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.duration')); ?></span>
                                    <span><?php echo e($data->duration); ?> <?php echo e(__('message.min')); ?> x <?php echo e($data->per_minute_drive); ?>/<?php echo e(__('message.min')); ?></span>
                                    <span class=""><?php echo e(getPriceFormat($data->per_minute_drive_charge)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.wait_time')); ?></span>
                                    <?php if($data->waiting_time == 0): ?>
                                        <span></span>
                                    <?php else: ?>
                                        <span><?php echo e($data->waiting_time); ?> <?php echo e(__('message.min')); ?> x <?php echo e($data->per_minute_waiting); ?>/<?php echo e(__('message.min')); ?></span>
                                    <?php endif; ?>
                                    <span class=""><?php echo e(getPriceFormat($data->per_minute_waiting_charge)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.extra_charges')); ?></span>
                                    <?php if(count($data->extra_charges) > 0): ?>
                                        <?php
                                            $extra_charges = collect($data->extra_charges)->pluck('key')->implode(', ');
                                        ?>
                                        <span><?php echo e($extra_charges); ?></span>
                                    <?php else: ?>
                                        <span></span>
                                    <?php endif; ?>
                                    <span class=""><?php echo e(getPriceFormat($data->extra_charges_amount)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.tip')); ?></span>
                                    <span></span>
                                    <span class=""><?php echo e(getPriceFormat($data->tips)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.coupon_discount')); ?></span>
                                    <span></span>
                                    <span class=""><?php echo e(getPriceFormat($data->coupon_discount)); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.amount')); ?></span>
                                    <?php
                                        $total_amount = ( $data->tips ?? 0 ) + optional($data->payment)->total_amount;
                                    ?>
                                    <span class="font-weight-bold"><?php echo e(getPriceFormat($total_amount)); ?></span>
                                </li>
                            </ul>
                        <?php else: ?>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.payment_method')); ?></span>
                                    <span class="font-weight-bold"><?php echo e($data->payment_type ?? '-'); ?></span>
                                </li>
                                <li class="list-group-item d-flex flex-xl-row flex-column justify-content-between align-items-center align-items-xl-start px-0"> 
                                    <span><?php echo e(__('message.amount')); ?></span>
                                    <span class="font-weight-bold"><?php echo e(optional($data->payment)->total_amount == null ? '-' : getPriceFormat(optional($data->payment)->total_amount)); ?></span>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if(count($data->rideRequestHistory) > 0): ?>
                    <div class="card card-block">
                        <div class="card-header d-flex justify-content-between">
                            <div class="header-title">
                                <h4 class="card-title mb-0"><?php echo e(__('message.activity_timeline')); ?></h4>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="mm-timeline0 m-0 d-flex align-items-center justify-content-between position-relative">
                                <ul class="list-inline p-0 m-0">
    
                                    <?php $__currentLoopData = $data->rideRequestHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <div class="timeline-dots1 border-primary text-primary">
                                                <!-- <i class="ri-login-circle-line"></i> -->
                                            </div>
                                            <h6 class="float-left mb-1"><?php echo e(__('message.'.$history->history_type)); ?></h6>
                                            <small class="float-right mt-1"><?php echo e($history->datetime); ?></small>
                                            <div class="d-inline-block w-100">
                                                <p><?php echo e($history->history_message); ?></p>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-lg-4">
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.detail_form_title', [ 'form' => __('message.rider') ])); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <img src="<?php echo e(getSingleMedia(optional($data->rider), 'profile_image',null)); ?>" alt="rider-profile" class="img-fluid avatar-60 rounded-small">
                            </div>
                            <div class="col-9">
                                <?php if( $data->is_ride_for_other == 0 ): ?>
                                <p class="mb-0"><?php echo e(optional($data->rider)->display_name); ?></p>
                                <p class="mb-0"><?php echo e(optional($data->rider)->contact_number); ?></p>
                                <p class="mb-0"><?php echo e(optional($data->rider)->email); ?></p>
                                <p class="mb-0"><?php echo e(optional($data->rideRequestRiderRating())->rating); ?>

                                    <?php if( optional($data->rideRequestRiderRating())->rating > 0 ): ?>
                                        <i class="fa fa-star" style="color: yellow"></i>
                                    <?php endif; ?>
                                </p>
                                <?php else: ?>
                                    <p class="mb-0"><b><?php echo e(__('message.booked_by')); ?>:</b> <?php echo e(optional($data->rider)->display_name); ?></p>
                                    <?php if(!empty($data->other_rider_data)): ?>
                                        <?php $__currentLoopData = $data->other_rider_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p class="mb-0"><?php echo e($key ?? ''); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if( isset($data->driver) ): ?>
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.detail_form_title', [ 'form' => __('message.driver') ])); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <img src="<?php echo e(getSingleMedia(optional($data->driver), 'profile_image',null)); ?>" alt="driver-profile" class="img-fluid avatar-60 rounded-small">
                            </div>
                            <div class="col-9">
                                <p class="mb-0"><?php echo e(optional($data->driver)->display_name); ?></p>
                                <p class="mb-0"><?php echo e(optional($data->driver)->contact_number); ?></p>
                                <p class="mb-0"><?php echo e(optional($data->driver)->email); ?></p>
                                <p class="mb-0"><?php echo e(optional($data->rideRequestDriverRating())->rating); ?>

                                    <?php if( optional($data->rideRequestDriverRating())->rating > 0 ): ?>
                                        <i class="fa fa-star" style="color: yellow"></i>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.detail_form_title', [ 'form' => __('message.service') ])); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-3">
                                <img src="<?php echo e(getSingleMedia($data->service, 'service_image',null)); ?>" alt="service-detail" class="img-fluid avatar-60 rounded-small">
                            </div>
                            <div class="col-9">
                                <p class="mb-0"><?php echo e(optional($data->service)->name); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/riderequest/show.blade.php ENDPATH**/ ?>