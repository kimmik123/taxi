<?php echo e(Form::model($flatArray,['method' => 'POST', 'route'=> 'saveLangContent', 'data-toggle' => 'validator'] )); ?>

    <input type="hidden" value="<?php echo e($filename); ?>" name="filename"/>
    <input type="hidden" value="<?php echo e($requestLang); ?>" name="requestLang"/>
    <table class="table language_table table-sm table-fixed">
        <thead>
            <tr>
                <th scope="col"><?php echo e(__('message.key')); ?></th>
                <th scope="col"><?php echo e(__('message.value')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $flatArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                   <td><?php echo e($val); ?> <small>(<?php echo e($key); ?>)</small></td>
                   <td><input class="form-control" name="<?php echo e($key); ?>" value="<?php echo e($val); ?>" /></td>
               </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php echo e(Form::submit( __('message.save'), ['class' => 'btn btn-md btn-primary float-right'])); ?>

<?php echo e(Form::close()); ?>

<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/language/index.blade.php ENDPATH**/ ?>