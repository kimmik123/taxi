<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, []); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<div class="container-fluid">
    <div class="row">            
        <div class="col-lg-12">
            <div class="card card-block card-stretch">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <h5 class="font-weight-bold"><?php echo e($pageTitle); ?></h5>
                        <a href="<?php echo e(route('driver.index')); ?>" class="float-right btn btn-sm btn-primary"><i class="fa fa-angle-double-left"></i> <?php echo e(__('message.back')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="card card-block p-card">
                <div class="profile-box">
                    <div class="profile-card rounded">
                        <img src="<?php echo e($profileImage); ?>" alt="01.jpg" class="avatar-100 rounded d-block mx-auto img-fluid mb-3">
                        <h3 class="font-600 text-white text-center mb-0"><?php echo e($data->display_name); ?></h3>
                        <p class="text-white text-center mb-5">
                            <?php
                                $status = 'danger';
                                $status_label = __('message.offline');
                                switch ($data->is_online) {
                                    case '1':
                                        $status = 'success';
                                        $status_label = __('message.online');
                                        break;
                                }
                            ?>
                            <span class="badge bg-<?php echo e($status); ?>"><?php echo e($status_label); ?></span>

                            <?php if( $data->is_available == 1 ): ?>
                                <span class="badge bg-success"><?php echo e(__('message.in_service')); ?></span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="pro-content rounded">
                        <div class="d-flex align-items-center mb-3">
                            <div class="p-icon mr-3"> 
                                <i class="fas fa-envelope"></i>
                            </div>
                            <p class="mb-0 eml"><?php echo e($data->email); ?></p>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="p-icon mr-3"> 
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <p class="mb-0"><?php echo e($data->contact_number); ?></p>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="p-icon mr-3"> 
                                
                                <?php if( $data->gender == 'female' ): ?>
                                    <i class="fas fa-female"></i>
                                <?php elseif( $data->gender == 'other' ): ?>
                                    <i class="fas fa-transgender"></i>
                                <?php else: ?>
                                    <i class="fas fa-male"></i>
                                <?php endif; ?>
                            </div>
                            <p class="mb-0"><?php echo e($data->gender); ?></p>
                        </div>
                        <?php
                            $rating = $data->rating ?? 0;
                        ?>
                        <?php if( $rating > 0 ): ?>
                            <div class="d-flex justify-content-center">
                                <div class="social-ic d-inline-flex rounded">
                                    <?php while($rating > 0 ): ?>
                                        <?php if($rating > 0.5): ?>
                                            <i class="fas fa-star" style="color: yellow"></i>
                                        <?php else: ?>
                                            <i class="fas fa-star-half" style="color: yellow"></i>
                                        <?php endif; ?>
                                        <?php $rating--; ?>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="card card-block">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title mb-0"><?php echo e(__('message.detail_form_title', [ 'form' => __('message.service') ])); ?></h4>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-3">
                            <img src="<?php echo e(getSingleMedia($data->service, 'service_image',null)); ?>" alt="service-detail" class="img-fluid avatar-60 rounded-small">
                        </div>
                        <div class="col-9">
                            <p class="mb-0"><?php echo e(optional($data->service)->name); ?></p>
                            <p class="mb-0"><?php echo e(optional($data->userDetail)->car_model); ?> ( <?php echo e(optional($data->userDetail)->car_color); ?> )</p>
                            <p class="mb-0"><?php echo e(optional($data->userDetail)->car_plate_number); ?></p>
                            <p class="mb-0"><?php echo e(optional($data->userDetail)->car_production_year); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <div class="col-lg-8">
            <div class="row">
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.detail_form_title', [ 'form' => __('message.bank') ])); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <h5><?php echo e(__('message.bank_name')); ?></h5>
                                <p class="mb-0"><?php echo e(optional($data->userBankAccount)->bank_name ?? '-'); ?></p>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e(__('message.bank_code')); ?></h5>
                                <p class="mb-0"><?php echo e(optional($data->userBankAccount)->bank_code ?? '-'); ?></p>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e(__('message.account_holder_name')); ?></h5>
                                <p class="mb-0"><?php echo e(optional($data->userBankAccount)->account_holder_name ?? '-'); ?></p>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e(__('message.account_number')); ?></h5>
                                <p class="mb-0"><?php echo e(optional($data->userBankAccount)->account_number ?? '-'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.total_earning')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat( $data->total_earning ) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.cash_earning')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat( $data->cash_earning ) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.wallet_earning')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat( $data->wallet_earning ) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.admin_commission')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat( $data->admin_commission ) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.driver_earning')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat( $data->driver_earning ) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.wallet_balance')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat(optional($data->userWallet)->total_amount) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">
                                <div class="">
                                    <p class="mb-1"><?php echo e(__('message.total_withdraw')); ?></p>
                                    <p></p>
                                    <h5><?php echo e(getPriceFormat(optional($data->userWallet)->total_withdrawn) ?? 0); ?> </h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.list_form_title', [ 'form' => __('message.wallethistory') ])); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e($dataTable->table(['class' => 'table  w-100'],false)); ?>

                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>
<?php $__env->startSection('bottom_script'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/driver/show.blade.php ENDPATH**/ ?>