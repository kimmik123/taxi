<footer class="mm-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6">
                <ul class="list-inline mb-0">
                    <!-- <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
                    <li class="list-inline-item"><a href="#">Terms of Use</a></li> -->
                </ul>
            </div>
            <div class="col-lg-6 text-right">
                <span class="mr-1">
                    <?php echo e(__('message.copyright')); ?> <?php echo e(date('Y')); ?> &copy; <a href="#" class=""><?php echo e(env('APP_NAME')); ?></a>
                    <?php echo e(__('message.all_rights_reserved')); ?>

                </span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/partials/_body_footer.blade.php ENDPATH**/ ?>