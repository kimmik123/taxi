<?php
    $auth_user= authSession();
?>
<?php echo e(Form::open(['route' => ['additionalfees.destroy', $id], 'method' => 'delete','data--submit'=>'additionalfees'.$id])); ?>

<div class="d-flex justify-content-end align-items-center">
    <?php if($auth_user->can('additionalfees edit')): ?>
    <a class="mr-2" href="<?php echo e(route('additionalfees.edit', $id)); ?>" title="<?php echo e(__('message.update_form_title',['form' => __('message.additionalfees') ])); ?>"><i class="fas fa-edit text-primary"></i></a>
    <?php endif; ?>
    
    <?php if($auth_user->can('additionalfees delete')): ?>
    <a class="mr-2 text-danger" href="javascript:void(0)" data--submit="additionalfees<?php echo e($id); ?>" 
        data--confirmation='true' data-title="<?php echo e(__('message.delete_form_title',['form'=> __('message.additionalfees') ])); ?>"
        title="<?php echo e(__('message.delete_form_title',['form'=>  __('message.additionalfees') ])); ?>"
        data-message='<?php echo e(__("message.delete_msg")); ?>'>
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php endif; ?>
</div>
<?php echo e(Form::close()); ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/additional_fees/action.blade.php ENDPATH**/ ?>