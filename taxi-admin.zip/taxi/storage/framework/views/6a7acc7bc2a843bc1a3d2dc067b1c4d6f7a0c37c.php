<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php $id = $id ?? null;?>
        <?php if(isset($id)): ?>
            <?php echo Form::model($data, ['route' => ['complaint.update', $id], 'method' => 'patch' , 'enctype' => 'multipart/form-data']); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['complaint.store'], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="new-user-info">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('subject',__('message.subject').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('subject',old('subject'),['placeholder' => __('message.subject'),'class' =>'form-control','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('ride_request_id', __('message.riderequest'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::select('ride_request_id', isset($id) ? [ $data->ride_request_id => '#'.$data->ride_request_id ] : [] , old('ride_request_id') , [
                                        'data-ajax--url' => route('ajax-list', [ 'type' => 'riderequest' ]),
                                        'data-placeholder' => __('message.select_field', [ 'name' => __('message.riderequest') ]),
                                        'class' =>'form-control select2js', 'required',
                                        'id' => 'ride_request_id'
                                        ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('rider_id', __('message.rider'), ['class' => 'form-control-label'])); ?>

                                    <p id="rider_name"><?php echo e(isset($id) ? optional($data->rider)->display_name : '-'); ?></p>
                                </div>
                                
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('driver_id', __('message.driver'), ['class' => 'form-control-label'])); ?>

                                    
                                    <p id="driver_name"><?php echo e(isset($id) ? optional($data->driver)->display_name : '-'); ?></p>
                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('complaint_by',__('message.complaint_by').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('complaint_by',[ 'rider' => __('message.rider') ,'driver' => __('message.driver') ], old('complaint_by') ,[ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('status',__('message.status'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::select('status',[ 'pending' => __('message.pending'), 'resolved' => __('message.resolved'), 'investigation' => __('message.investigation') ], old('status') ,[ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('description',__('message.description'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::textarea('description', null, ['class'=>"form-control textarea" , 'rows'=>3  , 'placeholder'=> __('message.description') ])); ?>

                                </div>
                            </div>
                            <hr>
                            <?php echo e(Form::submit( __('message.save'), ['class'=>'btn btn-md btn-primary float-right'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <?php $__env->startSection('bottom_script'); ?>
        <script>
            $(document).ready(function() {                
                $('#ride_request_id').on('select2:select', function (e) {
                    let data = e.params.data;
                    console.log(data);
                    $('#rider_name').text( data.rider['display_name'] )
                    if( data.driver_id != null ) {
                        $('#driver_name').text( data.driver['display_name'] )
                    } else {
                        $('#driver_name').text('-');
                    }
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/complaint/form.blade.php ENDPATH**/ ?>