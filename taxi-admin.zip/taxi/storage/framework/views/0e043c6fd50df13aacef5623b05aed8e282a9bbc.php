
<?php
    $auth_user= authSession();
?>
<?php echo e(Form::open(['route' => ['rider.destroy', $id], 'method' => 'delete','data--submit'=>'rider'.$id])); ?>

<div class="d-flex justify-content-end align-items-center">
    <?php if($auth_user->can('rider edit')): ?>
    <a class="mr-2" href="<?php echo e(route('rider.edit', $id)); ?>" title="<?php echo e(__('message.update_form_title',['form' => __('message.rider') ])); ?>"><i class="fas fa-edit text-primary"></i></a>
    <?php endif; ?>

    <?php if($auth_user->can('rider show')): ?>
        <a class="mr-2" href="<?php echo e(route('rider.show',$id)); ?>"><i class="fas fa-eye text-secondary"></i></a>
    <?php endif; ?>

    <?php if($auth_user->can('rider delete')): ?>
    <a class="mr-2 text-danger" href="javascript:void(0)" data--submit="rider<?php echo e($id); ?>" 
        data--confirmation='true' data-title="<?php echo e(__('message.delete_form_title',['form'=> __('message.rider') ])); ?>"
        title="<?php echo e(__('message.delete_form_title',['form'=>  __('message.rider') ])); ?>"
        data-message='<?php echo e(__("message.delete_msg")); ?>'>
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php endif; ?>
</div>
<?php echo e(Form::close()); ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/rider/action.blade.php ENDPATH**/ ?>