<div id="loading-center">
</div>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/partials/_body_loader.blade.php ENDPATH**/ ?>