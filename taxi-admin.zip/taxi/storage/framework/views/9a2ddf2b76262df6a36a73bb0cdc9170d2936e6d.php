<link rel="shortcut icon" class="site_favicon_preview" href="<?php echo e(getSingleMedia(appSettingData('get'), 'site_favicon', null)); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/backend-bundle.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('css/backend.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('vendor/remixicon/fonts/remixicon.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('css/vendor/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/confirmJS/jquery-confirm.min.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<?php if(isset($assets) && in_array('phone', $assets)): ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/intlTelInput/css/intlTelInput.css')); ?>">
<?php endif; ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/partials/_head.blade.php ENDPATH**/ ?>