<?php echo e(Form::open(['method' => 'POST','route' => ['walletSettingsUpdate'],'data-toggle'=>'validator'])); ?>

<?php echo e(Form::hidden('page', $page, ['class' => 'form-control'] )); ?>

    
    <div class="col-md-12 mt-20">
        <div class="row">
            <?php $__currentLoopData = $wallet_setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 form-group">
                    <?php if($key == 'preset_topup_amount' ): ?>
                        <?php echo e(Form::label($key,__('message.'.$key).' <span data-toggle="tooltip" data-placement="right" title="'.__('message.preset_topup_amount_info').'"><i class="las la-question-circle"></i></span>',['class'=>'form-control-label'],false )); ?>

                        <?php echo e(Form::text($key,$value ?? null,[ 'placeholder' => '10|50|100|500', 'class' => 'form-control' ])); ?>

                    <?php else: ?>
                        <?php echo e(Form::label($key,__('message.'.$key),['class'=>'form-control-label'] )); ?>

                        <?php if($key == 'min_amount_to_get_ride'): ?>
                            <?php echo e(Form::number($key,$value ?? null,[ 'placeholder' => __('message.'.$key), 'step' => 'any', 'class' => 'form-control' ])); ?>

                        <?php else: ?>
                            <?php echo e(Form::number($key,$value ?? null,[ 'placeholder' => __('message.'.$key), 'min' => 0, 'step' => 'any', 'class' => 'form-control' ])); ?>

                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php echo e(Form::submit(__('message.save'), ['class'=>"btn btn-md btn-primary float-md-right"])); ?>

<?php echo e(Form::close()); ?>

<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/setting/wallet-setting.blade.php ENDPATH**/ ?>