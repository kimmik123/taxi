<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php $id = $id ?? null;?>
        <?php if(isset($id)): ?>
            <?php echo Form::model($data, ['route' => ['driver.update', $id], 'method' => 'patch' , 'enctype' => 'multipart/form-data']); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['driver.store'], 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php endif; ?>
        <div class="row">
            <div class="col-xl-3 col-lg-4">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <div class="crm-profile-img-edit position-relative">
                                <img src="<?php echo e($profileImage ?? asset('images/user/1.jpg')); ?>" alt="User-Profile" class="crm-profile-pic rounded-circle avatar-100">
                                <div class="crm-p-image bg-primary">
                                    <svg class="upload-button" width="14" height="14" viewBox="0 0 24 24">
                                        <path fill="#ffffff" d="M14.06,9L15,9.94L5.92,19H5V18.08L14.06,9M17.66,3C17.41,3 17.15,3.1 16.96,3.29L15.13,5.12L18.88,8.87L20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18.17,3.09 17.92,3 17.66,3M14.06,6.19L3,17.25V21H6.75L17.81,9.94L14.06,6.19Z" />
                                    </svg>
                                    <input class="file-upload" type="file" accept="image/*" name="profile_image">
                                </div>
                            </div>
                            <div class="img-extension mt-3">
                                <div class="d-inline-block align-items-center">
                                    <span><?php echo e(__('message.only')); ?></span>

                                    <?php $__currentLoopData = config('constant.IMAGE_EXTENTIONS'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extention): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="javascript:void();">.<?php echo e($extention); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e(__('message.allowed')); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label"><?php echo e(__('message.status')); ?></label>
                            <div class="grid" style="--bs-gap: 1rem">
                                <div class="form-check g-col-6">
                                    <?php echo e(Form::radio('status', 'active' , old('status') || true, ['class' => 'form-check-input', 'id' => 'status-active' ])); ?>

                                    <?php echo e(Form::label('status-active', __('message.active'), ['class' => 'form-check-label' ])); ?>

                                </div>
                                <div class="form-check g-col-6">
                                    <?php echo e(Form::radio('status', 'inactive', old('status') , ['class' => 'form-check-input', 'id' => 'status-inactive' ])); ?>

                                    <?php echo e(Form::label('status-inactive', __('message.inactive'), ['class' => 'form-check-label' ])); ?>

                                </div>
                                <div class="form-check g-col-6">
                                    <?php echo e(Form::radio('status', 'pending', old('status') , ['class' => 'form-check-input', 'id' => 'status-pending' ])); ?>

                                    <?php echo e(Form::label('status-pending', __('message.pending'), ['class' => 'form-check-label' ])); ?>

                                </div>
                                <div class="form-check g-col-6">
                                    <?php echo e(Form::radio('status', 'banned', old('status') , ['class' => 'form-check-input', 'id' => 'status-banned' ])); ?>

                                    <?php echo e(Form::label('status-banned', __('message.banned'), ['class' => 'form-check-label' ])); ?>

                                </div>
                                <div class="form-check g-col-6">
                                    <?php echo e(Form::radio('status', 'reject', old('status') , ['class' => 'form-check-input', 'id' => 'status-reject' ])); ?>

                                    <?php echo e(Form::label('status-reject', __('message.reject'), ['class' => 'form-check-label' ])); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-9 col-lg-8">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?> <?php echo e(__('message.information')); ?></h4>
                        </div>
                        <div class="card-action">
                            <a href="<?php echo e(route('driver.index')); ?>" class="btn btn-sm btn-primary" role="button"><?php echo e(__('message.back')); ?></a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="new-user-info">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('first_name',__('message.first_name').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('first_name',old('first_name'),['placeholder' => __('message.first_name'),'class' =>'form-control','required'])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('last_name',__('message.last_name').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('last_name',old('last_name'),['placeholder' => __('message.last_name'),'class' =>'form-control','required'])); ?>

                                </div>
                                
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('email',__('message.email').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::email('email', old('email'), [ 'placeholder' => __('message.email'), 'class' => 'form-control', 'required' ])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('username',__('message.username').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('username', old('username'), ['class' => 'form-control', 'required', 'placeholder' => __('message.username') ])); ?>

                                </div>

                                <?php if(!isset($id)): ?>
                                    <div class="form-group col-md-6">
                                        <?php echo e(Form::label('password',__('message.password').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                        <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' =>  __('message.password') ])); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('contact_number',__('message.contact_number').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('contact_number', old('contact_number'),[ 'placeholder' => __('message.contact_number'), 'class' => 'form-control', 'id' => 'phone' ])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('gender',__('message.gender').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('gender',[ 'male' => __('message.male') ,'female' => __('message.female') , 'other' => __('message.other') ], old('gender') ,[ 'class' =>'form-control select2js','required'])); ?>

                                </div>
                                

                                 <!-- Service List -->
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('service_id', __('message.select_name',[ 'select' => __('message.service') ]),[ 'class' => 'form-control-label' ])); ?> 
                                    <?php echo e(Form::select('service_id', isset($id) ? [ optional($data->service)->id => optional($data->service)->name ] : [], old('service_id'), [
                                            'class' => 'select2js form-group service',
                                            'data-placeholder' => __('message.select_name',[ 'select' => __('message.service') ]),
                                            'data-ajax--url' => route('ajax-list', ['type' => 'service']),
                                        ])); ?>

                                </div>
                                
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('car_model',__('message.car_model').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userDetail[car_model]', old('userDetail[car_model]'), ['class' => 'form-control', 'placeholder' => __('message.car_model')])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('car_color',__('message.car_color').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userDetail[car_color]', old('userDetail[car_color]'), ['class' => 'form-control', 'placeholder' => __('message.car_color')])); ?>

                                </div>
                                
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('car_plate_number',__('message.car_plate_number').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userDetail[car_plate_number]', old('userDetail[car_plate_number]'), ['class' => 'form-control', 'placeholder' => __('message.car_plate_number')])); ?>

                                </div>
                                
                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('car_production_year',__('message.car_production_year').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userDetail[car_production_year]', old('userDetail[car_production_year]'), ['class' => 'form-control', 'placeholder' => __('message.car_production_year')])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('bank_name',__('message.bank_name').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userBankAccount[bank_name]', old('userBankAccount[bank_name]'), ['class' => 'form-control', 'placeholder' => __('message.bank_name')])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('bank_code',__('message.bank_code').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userBankAccount[bank_code]', old('userBankAccount[bank_code]'), ['class' => 'form-control', 'placeholder' => __('message.bank_code')])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('account_holder_nameaccount_holder_name',__('message.account_holder_name').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userBankAccount[account_holder_name]', old('userBankAccount[account_holder_name]'), ['class' => 'form-control', 'placeholder' => __('message.account_holder_name')])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('account_number',__('message.account_number').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('userBankAccount[account_number]', old('userBankAccount[account_number]'), ['class' => 'form-control', 'placeholder' => __('message.account_number')])); ?>

                                </div>

                                <div class="form-group col-md-6">
                                    <?php echo e(Form::label('address',__('message.address'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::textarea('address', null, ['class'=>"form-control textarea" , 'rows'=>3  , 'placeholder'=> __('message.address') ])); ?>

                                </div>
                            </div>
                            <hr>
                            <?php echo e(Form::submit( __('message.save'), ['class'=>'btn btn-md btn-primary float-right'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/driver/form.blade.php ENDPATH**/ ?>