
<?php
    $auth_user= authSession();
?>
<?php echo e(Form::open(['route' => ['service.destroy', $id], 'method' => 'delete','data--submit'=>'service'.$id])); ?>

<div class="d-flex justify-content-end align-items-center">
    <?php if($auth_user->can('service edit')): ?>
    <a class="mr-2" href="<?php echo e(route('service.edit', $id)); ?>" title="<?php echo e(__('message.update_form_title',['form' => __('message.service') ])); ?>"><i class="fas fa-edit text-primary"></i></a>
    <?php endif; ?>
    
    <?php if($auth_user->can('service delete')): ?>
    <a class="mr-2 text-danger" href="javascript:void(0)" data--submit="service<?php echo e($id); ?>" 
        data--confirmation='true' data-title="<?php echo e(__('message.delete_form_title',['form'=> __('message.service') ])); ?>"
        title="<?php echo e(__('message.delete_form_title',['form'=>  __('message.service') ])); ?>"
        data-message='<?php echo e(__("message.delete_msg")); ?>'>
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php endif; ?>
</div>
<?php echo e(Form::close()); ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/service/action.blade.php ENDPATH**/ ?>