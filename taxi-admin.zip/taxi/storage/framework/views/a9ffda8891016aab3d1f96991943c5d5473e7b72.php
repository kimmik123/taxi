<?php echo e(Form::open(['method' => 'POST','route' => ['rideSettingsUpdate'],'data-toggle'=>'validator'])); ?>

<?php echo e(Form::hidden('page', $page, ['class' => 'form-control'] )); ?>

    <div class="col-md-12 mt-20">
        <div class="row">
            <?php $__currentLoopData = $ride_setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 form-group">
                    <?php if($key == 'preset_tip_amount' ): ?>
                        <?php echo e(Form::label($key,__('message.'.$key).' <span data-toggle="tooltip" data-placement="right" title="'.__('message.preset_tip_amount_info').'"><i class="las la-question-circle"></i></span>',['class'=>'form-control-label'],false )); ?>

                        <?php echo e(Form::text($key,$value ?? null,[ 'placeholder' => '0|5|10|50', 'class' => 'form-control' ])); ?>

                    <?php elseif( $key == 'apply_additional_fee' ): ?>
                        <?php echo e(Form::label($key,__('message.'.$key),['class'=>'form-control-label'] )); ?>

                        <div class="d-block">
                            <div class="custom-control custom-radio custom-control-inline col-2">
                                <?php echo e(Form::radio('apply_additional_fee', '1' , old('apply_additional_fee') || true, ['class' => 'custom-control-input', 'id' => 'apply_additional_fee_yes' ])); ?>

                                <?php echo e(Form::label('apply_additional_fee_yes', __('message.yes'), ['class' => 'custom-control-label' ])); ?>

                            </div>
                            <div class="custom-control custom-radio custom-control-inline col-2">
                                <?php echo e(Form::radio('apply_additional_fee', '0' , old('apply_additional_fee'), ['class' => 'custom-control-input', 'id' => 'apply_additional_fee_no' ])); ?>

                                <?php echo e(Form::label('apply_additional_fee_no', __('message.no'), ['class' => 'custom-control-label' ])); ?>

                            </div>
                        </div>
                    <?php else: ?>
                        <?php echo e(Form::label($key,__('message.'.$key),['class'=>'form-control-label'] )); ?>

                        <?php echo e(Form::number($key,$value ?? null,[ 'placeholder' => __('message.'.$key), 'min' => 0, 'step' => 'any', 'class' => 'form-control' ])); ?>

                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php echo e(Form::submit(__('message.save'), ['class'=>"btn btn-md btn-primary float-md-right"])); ?>

<?php echo e(Form::close()); ?>

<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/setting/ride-setting.blade.php ENDPATH**/ ?>