<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php $id = $id ?? null;?>
        <?php if(isset($id)): ?>
            <?php echo Form::model($data, ['route' => ['additionalfees.update', $id], 'method' => 'patch' ]); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['additionalfees.store'], 'method' => 'post' ]); ?>

        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="new-user-info">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('title', __('message.title').' <span class="text-danger">*</span>',['class' => 'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('title', old('title'),[ 'placeholder' => __('message.title'),'class' =>'form-control','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('status',__('message.status').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('status',[ '1' => __('message.active'), '0' => __('message.inactive') ], old('status'), [ 'class' =>'form-control select2js','required'])); ?>

                                </div>
                                
                            </div>
                            <hr>
                            <?php echo e(Form::submit( __('message.save'), ['class'=>'btn btn-md btn-primary float-right'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <?php $__env->startSection('bottom_script'); ?>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/additional_fees/form.blade.php ENDPATH**/ ?>