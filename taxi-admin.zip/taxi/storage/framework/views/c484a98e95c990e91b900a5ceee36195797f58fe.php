<?php
    $auth_user= authSession();
?>
<?php echo e(Form::open(['route' => ['sos.destroy', $id], 'method' => 'delete','data--submit'=>'sos'.$id])); ?>

<div class="d-flex justify-content-end align-items-center">
    <?php if($auth_user->can('sos edit')): ?>
    <a class="mr-2" href="<?php echo e(route('sos.edit', $id)); ?>" title="<?php echo e(__('message.update_form_title',['form' => __('message.sos') ])); ?>"><i class="fas fa-edit text-primary"></i></a>
    <?php endif; ?>

    <?php if($auth_user->can('sos delete')): ?>
    <a class="mr-2 text-danger" href="javascript:void(0)" data--submit="sos<?php echo e($id); ?>" 
        data--confirmation='true' data-title="<?php echo e(__('message.delete_form_title',['form'=> __('message.sos') ])); ?>"
        title="<?php echo e(__('message.delete_form_title',['form'=>  __('message.sos') ])); ?>"
        data-message='<?php echo e(__("message.delete_msg")); ?>'>
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php endif; ?>
</div>
<?php echo e(Form::close()); ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/sos/action.blade.php ENDPATH**/ ?>