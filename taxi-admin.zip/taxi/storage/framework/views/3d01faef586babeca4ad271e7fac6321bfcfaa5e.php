<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, []); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<div class="container-fluid">
    <div class="row">            
        <div class="col-lg-12">
            <div class="card card-block card-stretch">
                <div class="card-body p-0">
                    <div class="d-flex justify-content-between align-items-center p-3">
                        <h5 class="font-weight-bold"><?php echo e($pageTitle); ?></h5>
                        <a href="<?php echo e(route('rider.index')); ?>" class="float-right btn btn-sm btn-primary"><i class="fa fa-angle-double-left"></i> <?php echo e(__('message.back')); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-4">
            <div class="card card-block p-card">
                <div class="profile-box">
                    <div class="profile-card rounded">
                        <img src="<?php echo e($profileImage); ?>" alt="01.jpg" class="avatar-100 rounded d-block mx-auto img-fluid mb-3">
                        <h3 class="font-600 text-white text-center mb-0"><?php echo e($data->display_name); ?></h3>
                        <p class="text-white text-center mb-5">

                            <?php
                                $status = 'warning';
                                switch ($data->status) {
                                    case 'active':
                                        $status = 'success';
                                        break;
                                    case 'inactive':
                                        $status = 'danger';
                                        break;
                                    case 'banned':
                                        $status = 'dark';
                                        break;
                                }
                            ?>

                            <span class="text-capitalize badge bg-<?php echo e($status); ?> "><?php echo e($data->status); ?></span>
                        </p>
                    </div>
                    <div class="pro-content rounded">
                        <div class="d-flex align-items-center mb-3">
                            <div class="p-icon mr-3"> 
                                <i class="fas fa-envelope"></i>
                            </div>
                            <p class="mb-0 eml"><?php echo e($data->email); ?></p>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="p-icon mr-3"> 
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <p class="mb-0"><?php echo e($data->contact_number); ?></p>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <div class="p-icon mr-3"> 
                                
                                <?php if( $data->gender == 'female' ): ?>
                                    <i class="fas fa-female"></i>
                                <?php elseif( $data->gender == 'other' ): ?>
                                    <i class="fas fa-transgender"></i>
                                <?php else: ?>
                                    <i class="fas fa-male"></i>
                                <?php endif; ?>
                            </div>
                            <p class="mb-0"><?php echo e($data->gender); ?></p>
                        </div>
                        <?php
                            $rating = $data->rating ?? 0;
                        ?>
                        <?php if( $rating > 0 ): ?>
                            <div class="d-flex justify-content-center">
                                <div class="social-ic d-inline-flex rounded">
                                    <?php while($rating > 0 ): ?>
                                        <?php if($rating > 0.5): ?>
                                            <i class="fas fa-star" style="color: yellow"></i>
                                        <?php else: ?>
                                            <i class="fas fa-star-half" style="color: yellow"></i>
                                        <?php endif; ?>
                                        <?php $rating--; ?>
                                    <?php endwhile; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
       
        <div class="col-lg-8">
            <div class="row">
                <div class="col-md-4">
                    <div class="card card-block">
                        <div class="card-body">
                            <div class="top-block-one">                                
                                <p class="mb-1"><?php echo e(__('message.wallet_balance')); ?></p>
                                <p></p>
                                <h5><?php echo e(getPriceFormat(optional($data->userWallet)->total_amount) ?? 0); ?> </h5>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="card card-block">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title mb-0"><?php echo e(__('message.list_form_title', [ 'form' => __('message.riderequest') ])); ?></h4>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php echo e($dataTable->table(['class' => 'table  w-100'],false)); ?>

                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>
<?php $__env->startSection('bottom_script'); ?>
    <?php echo e($dataTable->scripts()); ?>

<?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/rider/show.blade.php ENDPATH**/ ?>