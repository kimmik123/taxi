<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php $id = $id ?? null;?>
        <?php if(isset($id)): ?>
            <?php echo Form::model($data, ['route' => ['coupon.update', $id], 'method' => 'patch' ]); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['coupon.store'], 'method' => 'post' ]); ?>

        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="new-user-info">
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('code',__('message.code').' <span class="text-danger">*</span>',[ 'class' => 'form-control-label' ], false )); ?>

                                    <?php if(!isset($id)): ?>
                                        <?php echo e(Form::text('code', old('code'),[ 'placeholder' => __('message.code'),'class' => 'form-control', 'required' ])); ?>

                                    <?php else: ?>
                                    <p><?php echo e($data->code); ?></p>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('title', __('message.title').' <span class="text-danger">*</span>',['class' => 'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('title', old('title'),[ 'placeholder' => __('message.title'),'class' =>'form-control','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('coupon_type',__('message.coupon_type').' <span class="text-danger">*</span>',[ 'class' => 'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('coupon_type', [ 'all' => __('message.all'), 'first_ride' => __('message.first_ride'), 'region_wise' => __('message.region_wise'), 'service_wise' => __('message.service_wise') ],  old('coupon_type'),[
                                        'class' =>'form-control select2js', 'required'])); ?>

                                </div>

                                <!-- Region List Multiple -->
                                <div class="form-group col-md-4 region_list">
                                    <?php echo e(Form::label('region_ids', __('message.select_name',[ 'select' => __('message.region') ]),[ 'class' => 'form-control-label' ])); ?>

                                    <br />
                                    
                                    <?php echo e(Form::select('region_ids[]', $selected_region, old('region_ids'), [
                                            'class' => 'select2js form-group region',
                                            'multiple' => 'multiple',
                                            'data-placeholder' => __('message.select_name',[ 'select' => __('message.region') ]),
                                            'data-ajax--url' => route('ajax-list', ['type' => 'region']),
                                        ])); ?>

                                </div>

                                <!-- Service List -->
                                <div class="form-group col-md-4 service_list">
                                    <?php echo e(Form::label('service_ids', __('message.select_name',[ 'select' => __('message.service') ]),[ 'class' => 'form-control-label' ])); ?>

                                    <br />
                                    
                                    <?php echo e(Form::select('service_ids[]', $selected_service, old('service_ids'), [
                                            'class' => 'select2js form-group service',
                                            'multiple' => 'multiple',
                                            'data-placeholder' => __('message.select_name',[ 'select' => __('message.service') ]),
                                            'data-ajax--url' => route('ajax-list', ['type' => 'service']),
                                        ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('usage_limit_per_rider', __('message.usage_limit_per_rider'), ['class' => 'form-control-label'] )); ?>

                                    <?php echo e(Form::number('usage_limit_per_rider', old('usage_limit_per_rider'), [ 'class' => 'form-control', 'min' => 0, 'placeholder' => __('message.usage_limit_per_rider') ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('start_date', __('message.start_date'), [ 'class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('start_date', old('start_date'),[ 'placeholder' => __('message.start_date'),'class' => 'form-control min-daterange-picker'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('end_date', __('message.end_date'), [ 'class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::text('end_date', old('end_date'),[ 'placeholder' => __('message.end_date'),'class' => 'form-control min-daterange-picker'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('discount_type',__('message.discount_type'), ['class' => 'form-control-label'])); ?>

                                    <?php echo e(Form::select('discount_type',[ 'fixed' => __('message.fixed') ,'percentage' => __('message.percentage') ], old('discount_type') ,[ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('discount', __('message.discount').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('discount', old('discount'), ['class' => 'form-control', 'min' => 0, 'step' => 'any', 'required', 'placeholder' => __('message.discount') ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('minimum_amount', __('message.minimum_amount').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('minimum_amount', old('minimum_amount'), ['class' => 'form-control', 'min' => 0, 'step' => 'any', 'required', 'placeholder' => __('message.minimum_amount') ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('maximum_discount', __('message.maximum_discount').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::number('maximum_discount', old('maximum_discount'), ['class' => 'form-control', 'min' => 0, 'step' => 'any', 'required', 'placeholder' => __('message.maximum_discount') ])); ?>

                                </div>
                                
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('status',__('message.status').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                    <?php echo e(Form::select('status',[ '1' => __('message.active'), '0' => __('message.inactive') ], old('status'), [ 'class' =>'form-control select2js','required'])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('description', __('message.description'), ['class'=>'form-control-label'] )); ?>

                                    <?php echo e(Form::textarea('description', null, ['class' => 'form-control textarea', 'rows' => 3, 'placeholder'=> __('message.description') ])); ?>

                                </div>
                            </div>
                            <hr>
                            <?php echo e(Form::submit( __('message.save'), ['class'=>'btn btn-md btn-primary float-right'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <?php $__env->startSection('bottom_script'); ?>
        <script>
            $(document).ready(function() {
                selected_coupon_type = $('#coupon_type :selected').val();
                changeCouponType(selected_coupon_type);
                $('#coupon_type').on('select2:select', function (e) {
                    var coupon_type = $(this).val();
                    changeCouponType(coupon_type);
                });
            });

            function changeCouponType(type='all') {

                switch(type) {
                    case 'region_wise':
                        $(document).find('.region_list').removeClass('d-none');
                        $(document).find('.service_list').addClass('d-none');
                        $(document).find('#usage_limit_per_rider').removeAttr('readonly');
                        break;
                    case 'service_wise':
                        $(document).find('.service_list').removeClass('d-none');
                        $(document).find('.region_list').addClass('d-none');
                        $(document).find('#usage_limit_per_rider').removeAttr('readonly');
                        break;
                    case 'first_ride':
                        $(document).find('.service_list').addClass('d-none');
                        $(document).find('.region_list').addClass('d-none');
                        $(document).find('#usage_limit_per_rider').val(1);
                        $(document).find('#usage_limit_per_rider').attr('readonly','true');
                        break;
                    default:
                        $(document).find('#usage_limit_per_rider').removeAttr('readonly')
                        $(document).find('.service_list').addClass('d-none');
                        $(document).find('.region_list').addClass('d-none');
                }
            }
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/coupon/form.blade.php ENDPATH**/ ?>