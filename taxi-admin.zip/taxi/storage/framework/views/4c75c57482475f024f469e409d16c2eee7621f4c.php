<?php
    $auth_user= authSession();
?>
    
<?php if($query->status == 0 && $auth_user->hasAnyRole(['admin']) ): ?>
    <div class="d-flex justify-content-end align-items-center">
        <a href="<?php echo e(route('withdraw.request.status', [ 'id' => $query->id, 'status' => 1 ])); ?>"
            data--confirmation='true' data-title="<?php echo e(__('message.withdrawrequest')); ?>"
            data--ajax='true'
            title="<?php echo e(__('message.approved')); ?>"
            data-message="<?php echo e(__('message.confirm_action_message', [ 'name' => __('message.approved') ])); ?>"
            data-datatable="reload">
            <span class="badge badge-success mr-1"><i class="fas fa-check"></i> </span>
        </a>

        <a href="<?php echo e(route('withdraw.request.status', [ 'id' => $query->id, 'status' => 2 ])); ?>"
            data--confirmation='true' data-title="<?php echo e(__('message.withdrawrequest')); ?>"
            data--ajax='true'
            title="<?php echo e(__('message.decline')); ?>"
            data-message="<?php echo e(__('message.confirm_action_message', [ 'name' => __('message.decline') ])); ?>"
            data-datatable="reload">
            <span class="badge badge-danger mr-1"> <i class="fas fa-ban"></i></span>
        </a>


        <a href="<?php echo e(route('bankdetail', $query->user_id )); ?>"
            data-title="<?php echo e(__('message.withdrawrequest')); ?>"
            data--ajax='true'
            class="loadRemoteModel"
            title="<?php echo e(__('message.detail_form_title',[ 'form' => __('message.bank') ])); ?>">
            <span class="badge badge-info mr-1"> <i class="fas fa-university"></i></span>
        </a>
    </div>
<?php else: ?>
    -
<?php endif; ?>

    
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/withdrawrequest/action.blade.php ENDPATH**/ ?>