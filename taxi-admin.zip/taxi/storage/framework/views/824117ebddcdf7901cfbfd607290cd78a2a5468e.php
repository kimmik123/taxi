<div class="row">
    <div class="col-lg-12">
        <ul class="nav nav-pills nav-fill tabslink" id="tab-text" role="tablist">
            <?php $__currentLoopData = config('constant.PAYMENT_GATEWAY_SETTING'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a href="javascript:void(0)" data-href="<?php echo e(route('layout_page')); ?>?page=payment-setting&type=<?php echo e($key); ?>" data-target=".paste_here" data-value="<?php echo e($key); ?>" id="pills-<?php echo e($key); ?>-tab-fill" data-toggle="tabajax" role="tab" class="nav-link <?php echo e($key == $type ? 'active' : ''); ?>" aria-controls="pills-<?php echo e($key); ?>" aria-selected="<?php echo e($key == $type ? true : false); ?>"> <?php echo e(__('message.'.$key)); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="card">
            <div class="card-body">
                <div class="tab-content" id="pills-tabContent-1">
                    <?php $__currentLoopData = config('constant.PAYMENT_GATEWAY_SETTING'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade <?php echo e($key == $type ? 'active show' : ''); ?>" id="pills-<?php echo e($key); ?>-fill" role="tabpanel" aria-labelledby="pills-<?php echo e($key); ?>-tab-fill">
                        <?php echo e(Form::model($payment_setting_data, [ 'method' => 'POST', 'route' => ['paymentSettingsUpdate'], 'enctype'=>'multipart/form-data', 'data-toggle' => 'validator' ])); ?>

                            <?php echo e(Form::hidden('id', null, [ 'class' => 'form-control'] )); ?>

                            <?php echo e(Form::hidden('type', $key , [ 'class' => 'form-control' ])); ?>

                            <div class="row">
                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('title',__('message.title').' <span class="text-danger">*</span>',['class'=>'form-control-label'], false )); ?>

                                    <?php echo e(Form::text('title',old('title'),[ 'placeholder' => __('message.title'), 'class' => 'form-control', 'required' ])); ?>

                                </div>

                                <?php if( $key != 'cash' ): ?>
                                    <div class="form-group col-md-4">
                                        <label class="d-block"><?php echo e(__('message.mode')); ?> </label>
                                        <div class="custom-control custom-radio custom-control-inline col-2">
                                            <?php echo e(Form::radio('is_test', '1' , old('is_test') || true, ['class' => 'custom-control-input', 'id' => 'is_test_test_'.$key ])); ?>

                                            <?php echo e(Form::label('is_test_test_'.$key, __('message.test'), ['class' => 'custom-control-label' ])); ?>

                                        </div>
                                        <div class="custom-control custom-radio custom-control-inline col-2">
                                            <?php echo e(Form::radio('is_test', '0' , old('is_test'), ['class' => 'custom-control-input', 'id' => 'is_test_live_'.$key ])); ?>

                                            <?php echo e(Form::label('is_test_live_'.$key, __('message.live'), ['class' => 'custom-control-label' ])); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if( $key != 'cash' ): ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="mb-3"><?php echo e(__('message.test')); ?></h5>
                                    <hr>
                                    <?php if( is_array($value) ): ?>
                                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-group">
                                                <?php echo e(Form::label('test_value['.$val.']',__('message.'.$val),['class'=>'form-control-label'] )); ?>

                                                <?php echo e(Form::text('test_value['.$val.']',null,[ 'placeholder' => __('message.'.$val), 'class' => 'form-control' ])); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <h5 class="mb-3"><?php echo e(__('message.live')); ?></h5>
                                    <hr>
                                    <?php if( is_array($value) ): ?>
                                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="form-group">
                                                <?php echo e(Form::label('live_value['.$val.']',__('message.'.$val),['class'=>'form-control-label'] )); ?>

                                                <?php echo e(Form::text('live_value['.$val.']',null,[ 'placeholder' => __('message.'.$val), 'class' => 'form-control' ])); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php if( $key != 'cash' ): ?>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <?php echo e(Form::label('status',__('message.status').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                        <?php echo e(Form::select('status',[ '1' => __('message.active'), '0' => __('message.inactive') ], old('status'), [ 'class' =>'form-control select2js','required'])); ?>

                                    </div>
                                    <div class="form-group col-md-4">
                                        <label class="form-control-label" for="image"><?php echo e(__('message.image')); ?> </label>
                                        <div class="custom-file">
                                            <input type="file" name="gateway_image" class="custom-file-input" accept="image/*">
                                            <label class="custom-file-label"><?php echo e(__('message.choose_file',['file' =>  __('message.image') ])); ?></label>
                                        </div>
                                        <span class="selected_file"></span>
                                    </div>
        
                                    <?php if( isset($payment_setting_data) && getMediaFileExit($payment_setting_data, 'gateway_image')): ?>
                                        <div class="col-md-2 mb-2">
                                            <img id="gateway_image_preview" src="<?php echo e(getSingleMedia($payment_setting_data,'gateway_image')); ?>" alt="gateway-image" class="attachment-image mt-1">
                                            <a class="text-danger remove-file" href="<?php echo e(route('remove.file', ['id' => $payment_setting_data->id, 'type' => 'gateway_image'])); ?>"
                                                data--submit='confirm_form' data--confirmation='true'
                                                data--ajax='true' data-toggle='tooltip'
                                                title='<?php echo e(__("message.remove_file_title" , ["name" =>  __("message.image") ])); ?>'
                                                data-title='<?php echo e(__("message.remove_file_title" , ["name" =>  __("message.image") ])); ?>'
                                                data-message='<?php echo e(__("message.remove_file_msg")); ?>'>
                                                <i class="ri-close-circle-line"></i>
                                            </a>
                                        </div>
                                        <?php else: ?>
                                        <div class="col-md-2 mb-2">
                                            <img src="<?php echo e(asset('images/'.$key.'.png')); ?>" alt="gateway-image" class="attachment-image mt-1">
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <hr>
                        <?php echo e(Form::submit(__('message.save'), ['class'=>"btn btn-md btn-primary float-md-right"])); ?>

                        <?php echo e(Form::close()); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/setting/payment-setting.blade.php ENDPATH**/ ?>