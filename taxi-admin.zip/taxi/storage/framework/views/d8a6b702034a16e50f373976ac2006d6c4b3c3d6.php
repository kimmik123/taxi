<?php echo e(Form::model($setting_value, ['method' => 'POST','route' => ['settingUpdate'],'enctype'=>'multipart/form-data','data-toggle'=>'validator'])); ?>

    <?php echo e(Form::hidden('id', null, ['class' => 'form-control'] )); ?>

    <?php echo e(Form::hidden('page', $page, ['class' => 'form-control'] )); ?>

    <div class="row">
        <?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12 col-sm-12 card shadow mb-10">
                <div class="card-header">
                    <h4><?php echo e($key); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_keys => $sub_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $data=null;
                                foreach($setting_value as $v){

                                    if($v->key==($key.'_'.$sub_keys)){
                                        $data = $v;
                                    }
                                }
                                $class = 'col-md-6';
                                $type = 'text';
                                switch ($key){
                                    case 'FIREBASE':
                                        $class = 'col-md-12';
                                        break;
                                    case 'COLOR' : 
                                        $type = 'color';
                                        break;
                                    case 'DISTANCE' :
                                        $type = 'number';
                                        break;
                                    default : break;
                                }
                            ?>
                            <div class=" <?php echo e($class); ?> col-sm-12">
                                <div class="form-group">
                                    <label for="<?php echo e($key.'_'.$sub_keys); ?>"><?php echo e(str_replace('_',' ',$sub_keys)); ?> </label>
                                    <?php echo e(Form::hidden('type[]', $key , ['class' => 'form-control'] )); ?>

                                    <input type="hidden" name="key[]" value="<?php echo e($key.'_'.$sub_keys); ?>">
                                    <?php if($key == 'CURRENCY' && $sub_keys == 'CODE'): ?>
                                        <?php
                                            $currency_code = $data->value ?? 'USD';
                                            $currency = currencyArray($currency_code);
                                        ?>
                                        <select class="form-control select2js" name="value[]" id="<?php echo e($key.'_'.$sub_keys); ?>">
                                            <?php $__currentLoopData = currencyArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($array['code']); ?>" <?php echo e($array['code'] == $currency_code  ? 'selected' : ''); ?>> ( <?php echo e($array['symbol']); ?>  ) <?php echo e($array['name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php elseif($key == 'CURRENCY' && $sub_keys == 'POSITION'): ?>
                                        <?php echo e(Form::select('value[]',['left' => __('message.left') , 'right' => __('message.right') ], isset($data) ? $data->value : 'left',[ 'class' =>'form-control select2js'])); ?>

                                    <?php elseif($key == 'RIDE' && $sub_keys == 'FOR_OTHER'): ?>
                                        <?php echo e(Form::select('value[]',['0' => __('message.no'), '1' => __('message.yes') ], isset($data) ? $data->value : '0', [ 'class' =>'form-control select2js'] )); ?>

                                    <?php else: ?>
                                        <input type="<?php echo e($type); ?>" name="value[]" value="<?php echo e(isset($data) ? $data->value : null); ?>" id="<?php echo e($key.'_'.$sub_keys); ?>" <?php echo e($type == 'number' ? "min=0 step='any'" : ''); ?> class="form-control form-control-lg" placeholder="<?php echo e(str_replace('_',' ',$sub_keys)); ?>">
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-12">
                            <?php echo Form::submit( __('message.save'), [ 'class' => 'btn btn-md btn-primary' ]); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php echo e(Form::submit(__('message.save'), ['class'=>"btn btn-md btn-primary float-md-right"])); ?>

<?php echo e(Form::close()); ?>


<script>
    $(document).ready(function() {
        $('.select2js').select2();
    });
</script>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/setting/mobile-config.blade.php ENDPATH**/ ?>