
<?php
    $auth_user= authSession();
?>
<?php echo e(Form::open(['route' => ['riderequest.destroy', $id], 'method' => 'delete','data--submit'=>'riderequest'.$id])); ?>

<div class="d-flex justify-content-end align-items-center">
    <?php if($auth_user->can('riderequest show')): ?>
    <a class="mr-2" href="<?php echo e(route('riderequest.show',$id)); ?>"><i class="fas fa-eye text-secondary"></i></a>
    <?php endif; ?>

    <?php if($auth_user->can('riderequest delete')): ?>
    <a class="mr-2" href="javascript:void(0)" data--submit="riderequest<?php echo e($id); ?>" 
        data--confirmation='true' data-title="<?php echo e(__('message.delete_form_title',['form'=> __('message.riderequest') ])); ?>"
        title="<?php echo e(__('message.delete_form_title',['form'=>  __('message.riderequest') ])); ?>"
        data-message='<?php echo e(__("message.delete_msg")); ?>'>
        <i class="fas fa-trash-alt text-danger"></i>
    </a>
    <?php endif; ?>
</div>
<?php echo e(Form::close()); ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/riderequest/action.blade.php ENDPATH**/ ?>