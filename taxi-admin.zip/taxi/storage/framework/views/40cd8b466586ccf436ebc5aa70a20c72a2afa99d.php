
<?php
    $auth_user= authSession();
?>
<?php echo e(Form::open(['route' => ['driver.destroy', $id], 'method' => 'delete','data--submit'=>'driver'.$id])); ?>

<div class="d-flex justify-content-end align-items-center">
    <?php if($auth_user->can('driver edit')): ?>
    <a class="mr-2" href="<?php echo e(route('driver.edit', $id)); ?>" title="<?php echo e(__('message.update_form_title',['form' => __('message.driver') ])); ?>"><i class="fas fa-edit text-primary"></i></a>
    <?php endif; ?>
    
    <?php if( $data->status == 'active' && $auth_user->can('driver show') ): ?>
        <a class="mr-2" href="<?php echo e(route('driver.show',$id)); ?>"><i class="fas fa-eye text-secondary"></i></a>
    <?php endif; ?>

    <?php if($auth_user->can('driver delete')): ?>
    <a class="mr-2 text-danger" href="javascript:void(0)" data--submit="driver<?php echo e($id); ?>" 
        data--confirmation='true' data-title="<?php echo e(__('message.delete_form_title',['form'=> __('message.driver') ])); ?>"
        title="<?php echo e(__('message.delete_form_title',['form'=>  __('message.driver') ])); ?>"
        data-message='<?php echo e(__("message.delete_msg")); ?>'>
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php endif; ?>
</div>
<?php echo e(Form::close()); ?><?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/driver/action.blade.php ENDPATH**/ ?>