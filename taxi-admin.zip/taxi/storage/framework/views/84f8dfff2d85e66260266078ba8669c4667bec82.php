<?php if (isset($component)) { $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MasterLayout::class, ['assets' => $assets ?? []]); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php $id = $id ?? null;?>
        <?php if(isset($id)): ?>
            <?php echo Form::model($data, ['route' => ['driverdocument.update', $id], 'method' => 'patch', 'enctype' => 'multipart/form-data' ]); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['driverdocument.store'], 'method' => 'post', 'enctype' => 'multipart/form-data' ]); ?>

        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <div class="header-title">
                            <h4 class="card-title"><?php echo e($pageTitle); ?></h4>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="new-user-info">
                            <div class="row">
                                <?php if(auth()->user()->hasAnyRole(['admin','demo_admin'])): ?>
                                    <div class="form-group col-md-4">
                                        <?php echo e(Form::label('driver_id', __('message.select_name',[ 'select' => __('message.driver') ]).' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                        <?php echo e(Form::select('driver_id', isset($id) ? [ optional($data->driver)->id => optional($data->driver)->display_name] : [], old('driver_id'), [
                                            'class' => 'select2js form-group driver',
                                            'required',
                                            'data-placeholder' => __('message.select_name',[ 'select' => __('message.driver') ]),
                                            'data-ajax--url' => route('ajax-list', ['type' => 'driver', 'status' => 'pending' ]),
                                        ])); ?>

                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->hasRole('fleet')): ?>
                                    <div class="form-group col-md-4">
                                        <?php echo e(Form::label('driver_id', __('message.select_name',[ 'select' => __('message.driver') ]).' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                        <?php echo e(Form::select('driver_id', isset($id) ? [ optional($data->driver)->id => optional($data->driver)->display_name] : [], old('driver_id'), [
                                            'class' => 'select2js form-group driver',
                                            'required',
                                            'data-placeholder' => __('message.select_name',[ 'select' => __('message.driver') ]),
                                            'data-ajax--url' => route('ajax-list', ['type' => 'driver', 'fleet_id' => auth()->user()->id, 'status' => 'pending'  ]),
                                        ])); ?>

                                    </div>
                                <?php endif; ?>

                                <?php
                                    $is_required = isset($id) && optional($data->document)->is_required == 1 ? '*' : '';
                                    $has_expiry_date = isset($id) && optional($data->document)->has_expiry_date == 1 ? 1 : '';
                                ?>

                                <div class="form-group col-md-4">
                                    <?php echo e(Form::label('document_id', __('message.select_name',[ 'select' => __('message.document') ]).' <span class="text-danger">* </span>',['class' => 'form-control-label' ],false)); ?>

                                    <?php echo e(Form::select('document_id', isset($id) ? [optional($data->document)->id => optional($data->document)->name." ".$is_required] : [], old('document_id'), [
                                            'class' => 'select2js form-group document_id',
                                            'id' => 'document_id',
                                            'required',
                                            'data-placeholder' => __('message.select_name',[ 'select' => __('message.document') ]),
                                            'data-ajax--url' => route('ajax-list', ['type' => 'document']),
                                        ])); ?>

                                </div>

                                <div class="form-group col-md-4">
                                    <label class="form-control-label" for="expire_date"><?php echo e(__('message.expire_date')); ?> <span class="text-danger" id="has_expiry_date"><?php echo e($has_expiry_date == 1 ? '*' : ''); ?></span> </label>
                                    <?php echo e(Form::text('expire_date', old('expire_date'),[ 'class' =>'form-control min-datepicker', 'placeholder' => __('message.expire_date'), 'required' => $has_expiry_date == 1 ? 'required' : null ])); ?>

                                </div>
                                
                                <?php if(auth()->user()->hasAnyRole(['admin','demo_admin'])): ?>
                                    <div class="form-group col-md-4">
                                        <?php echo e(Form::label('is_verified', __('message.is_verify').' <span class="text-danger">*</span>',['class'=>'form-control-label'],false)); ?>

                                        <?php echo e(Form::select('is_verified',[ '0' => __('message.pending'), '1' => __('message.approved'), '2' => __('message.rejected') ], old('is_verified'), [ 'id' => 'is_verified', 'class' => 'form-control select2js', 'required'])); ?>

                                    </div>
                                <?php endif; ?>

                                <div class="form-group col-md-4">
                                    <label class="form-control-label" for="driver_document"><?php echo e(__('message.upload_document')); ?> <span class="text-danger" id="document_required"></span> </label>
                                    <div class="custom-file">
                                        <input type="file" id="driver_document" name="driver_document" class="custom-file-input" >
                                        <label class="custom-file-label"><?php echo e(__('message.choose_file', [ 'file' => __('message.document') ])); ?></label>
                                    </div>
                                    <span class="selected_file"></span>
                                </div>
                                <?php if( isset($id) && getMediaFileExit($data, 'driver_document')): ?>
                                    <div class="col-md-2 mb-2">
                                        <?php
                                            $file_extention = config('constant.IMAGE_EXTENTIONS');
                                            $image = getSingleMedia($data,'driver_document');
                                            
                                            $extention = in_array(strtolower(imageExtention($image)),$file_extention);
                                        ?>
                                            <?php if($extention): ?>   
                                                <img id="driver_document_preview" src="<?php echo e($image); ?>" alt="#" class="attachment-image mt-1" >
                                            <?php else: ?>
                                                <img id="driver_document_preview" src="<?php echo e(asset('images/file.png')); ?>" class="attachment-file">
                                            <?php endif; ?>
                                            <a class="text-danger remove-file" href="<?php echo e(route('remove.file', ['id' => $data->id, 'type' => 'driver_document'])); ?>"
                                                data--submit="confirm_form"
                                                data--confirmation='true'
                                                data--ajax="true"
                                                title='<?php echo e(__("message.remove_file_title" , ["name" =>  __("message.image") ])); ?>'
                                                data-title='<?php echo e(__("message.remove_file_title" , ["name" =>  __("message.image") ])); ?>'
                                                data-message='<?php echo e(__("message.remove_file_msg")); ?>'>
                                                <i class="ri-close-circle-line"></i>
                                            </a>
                                            <a href="<?php echo e($image); ?>" class="d-block mt-2" download target="_blank"><i class="fas fa-download "></i> <?php echo e(__('message.download')); ?></a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <hr>
                            <?php echo e(Form::submit( __('message.save'), ['class'=>'btn btn-md btn-primary float-right'])); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>
    <?php $__env->startSection('bottom_script'); ?>
        <script type="text/javascript">
            (function($) {
                "use strict";
                    $(document).ready(function(){ 
                        $(document).on('change' , '#document_id' , function (){
                            var data = $('#document_id').select2('data')[0];

                            console.log(data);
                            if(data.is_required == 1)
                            {
                                $('#document_required').text('*');
                                $('#driver_document').attr('required');
                            } else {
                                $('#document_required').text('');
                                $('#driver_document').attr('required', false);
                            }

                            if(data.has_expiry_date == 1)
                            {
                                $('#has_expiry_date').text('*');
                                $('#expire_date').attr('required');
                            } else {
                                $('#has_expiry_date').text('');
                                $('#expire_date').attr('required', false);
                            }
                        })
                    })
            })(jQuery);
        </script>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23)): ?>
<?php $component = $__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23; ?>
<?php unset($__componentOriginalc6e081c8432fe1dd6b4e43af4871c93447ee9b23); ?>
<?php endif; ?>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/driver_document/form.blade.php ENDPATH**/ ?>