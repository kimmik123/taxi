<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <section class="login-content">
        <div class="container h-100">
            <div class="row align-items-center justify-content-center h-100">
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-body">
                            <div class="auth-logo">
                                <img src="<?php echo e(getSingleMedia(appSettingData('get'),'site_logo',null)); ?>" class="img-fluid mode light-img rounded-normal" alt="logo">
                                <img src="<?php echo e(getSingleMedia(appSettingData('get'),'site_dark_logo',null)); ?>" class="img-fluid mode dark-img rounded-normal darkmode-logo site_dark_logo_preview" alt="dark-logo">
                            </div>
                            <h2 class="mb-2 text-center"><?php echo e(__('auth.reset_password')); ?></h2>
                            
                            <!-- Validation Errors -->
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php echo e(Form::open(['route' => 'password.update', 'method' => 'post', 'data-toggle' => 'validator' ])); ?>

                                <!-- Password Reset Token -->
                                <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">
                                <!-- Email Address -->
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <?php echo e(Form::label('email',__('message.email').' <span class="text-danger">*</span>', ['class' => 'form-control-label'],false)); ?>

                                        <?php echo e(Form::email('email',old('email') ?? $request->email,['placeholder' => __('message.email'),'class' =>'form-control','required'])); ?>

                                    </div>
                                </div>

                                <!-- Password -->
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <?php echo e(Form::label('password',__('message.password').' <span class="text-danger">*</span>', ['class' => 'form-control-label'],false)); ?>

                                        <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => __('message.password'), 'required'])); ?>

                                    </div>
                                </div>

                                <!-- Confirm Password -->
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <?php echo e(Form::label('password_confirmation',__('auth.password_confirmation').' <span class="text-danger">*</span>', ['class' => 'form-control-label'],false)); ?>

                                        <?php echo e(Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => __('auth.password_confirmation'), 'required'])); ?>

                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">  <?php echo e(__('auth.reset_password')); ?></button>
                            <?php echo e(Form::close()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH /home/yhvzuavy/public_html/taxi/resources/views/auth/reset-password.blade.php ENDPATH**/ ?>